/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:controller del entrenador
 */
package controller;

import entity.Entrenador;
import service.EntrenadorServiceImpl;
import service.IEntrenadorService;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EntrenadorController {

    IEntrenadorService service = new EntrenadorServiceImpl();
    
      /**
       * El método crea un entrenador
       * @param lista
       * @param entrenador 
       */
    public void crearRegistro(List<Entrenador> lista, Entrenador entrenador) {
        service.crearRegistro(lista, entrenador);
    }

    /**
     * El método elimina un entrenador
     * @param lista
     * @param nombre 
     */
    public void eliminarRegistro(List<Entrenador> lista, String nombre) {
        service.eliminarRegistro(lista, nombre);
    }

    /**
     *El método actualiza un entrenador
     * @param lista
     * @param entrenador 
     */
    public void actualizarRegistro(List<Entrenador> lista, Entrenador entrenador) {
        service.actualizarRegistro(lista, entrenador);
    }

    /**
     * /El método muestra un entrenador
     * @param lista
     * @param modelo 
     */
    public void mostrarRegistro(List<Entrenador> lista, DefaultTableModel modelo) {
        service.mostrarRegistro(lista, modelo);
    }

}
