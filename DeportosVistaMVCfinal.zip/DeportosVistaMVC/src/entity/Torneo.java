/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:22/05/2023
*Fecha de actualización:23/05/2023
*Descripción:Esta es la clase jugador que tiene una clase padre persona
 */
package entity;

/**
 *
 * Se declararon los atributos de la clase con sus getter and setter
 */
public class Torneo {

    private String nombreTorneo;
    private String categoria;

    public Torneo() {
    }

    public Torneo(String nombreTorneo, String categoria) {
        this.nombreTorneo = nombreTorneo;
        this.categoria = categoria;
    }

    public String getNombreTorneo() {
        return nombreTorneo;
    }

    public void setNombreTorneo(String nombreTorneo) {
        this.nombreTorneo = nombreTorneo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

}
