/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:17/05/2023
*Fecha de actualización:17/05/2023
*Descripción:Esta es la clase jugador que tiene una clase padre persona
 */
package entity;

/**
 *
 * Se declararon los atributos de la clase con sus getter and setter
 */
public class Jugador extends Persona {

    private String posicion;
    private String numeroCamiseta;
    private String equipo;// composicion a equipo

    public Jugador() {
    }

    public Jugador(String posicion, String numeroCamiseta, String equipo) {

        this.posicion = posicion;
        this.numeroCamiseta = numeroCamiseta;
        this.equipo = equipo;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public String getNumeroCamiseta() {
        return numeroCamiseta;
    }

    public void setNumeroCamiseta(String numeroCamiseta) {
        this.numeroCamiseta = numeroCamiseta;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

}
