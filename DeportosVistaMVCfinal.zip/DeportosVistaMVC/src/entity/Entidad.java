/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:20/05/2023
*Fecha de actualización:21/05/2023
*Descripción:La clase entidad es la clase padre de equipo
 */
package entity;

/**
 * Se declararon los atributos de entidad con sus getter and setter
 *
 */
public class Entidad {

    private String nombre;

    public Entidad() {
    }

    public Entidad(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
