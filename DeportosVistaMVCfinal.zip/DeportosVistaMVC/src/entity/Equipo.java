/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:15/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Esta es la clase equipo se le agregan las composiones.
 */
package entity;


/**
 *
 * Esta es la clase equipo que tiene una clase padre entidad
 */
public class Equipo extends Entidad {

    private String nombre;
    private String estadio;

    public Equipo() {
    }

    public Equipo(String nombre, String estadio) {
        this.nombre = nombre;
        this.estadio = estadio;

    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

}
