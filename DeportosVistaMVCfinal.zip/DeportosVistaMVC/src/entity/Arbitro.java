/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:22/05/2023
*Fecha de actualización:22/05/2023
*Descripción:Esta es la clase árbitro tiene una clase padre persona
 */
package entity;

/**
 * Se declararon los atributos del árbitro junto a sus getter and setter
 *
 */
public class Arbitro extends Persona {

    private String experiencia;
    private String nivel;

    public Arbitro() {
    }

    public Arbitro(String experiencia, String nivel) {
        this.experiencia = experiencia;
        this.nivel = nivel;
    }

    public String getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(String experiencia) {
        this.experiencia = experiencia;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

}
