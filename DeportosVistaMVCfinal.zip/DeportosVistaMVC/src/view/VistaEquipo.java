/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:15/05/2023
*Fecha de actualización:15/05/2023
*Descripción:.ventana vista
 */
package view;

import controller.EquipoController;
import entity.Equipo;
import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VistaEquipo extends javax.swing.JFrame {

    private final EquipoController equipoController;
    private final MenuVista menuVista;

    private final DefaultTableModel modelo;

    /**
     * el constructor de la clase VistaEquipo realiza configuraciones iniciales,
     * como la asignación de imágenes de fondo, la creación de instancias de
     * controladores y la obtención del modelo de la tabla para administrar 
     * los datos de los equipos en la ventana.
     * @param menuVista 
     */
    public VistaEquipo(MenuVista menuVista) {
        initComponents();
        
        ImageIcon imagen = new ImageIcon("./src/images/cancha.jpg");
        Icon icono = new ImageIcon(imagen.getImage().getScaledInstance
        (wallpaper.getWidth(),
                wallpaper.getHeight(), Image.SCALE_DEFAULT));
        wallpaper.setIcon(icono);

        equipoController = new EquipoController();
        this.menuVista = menuVista;
        modelo = (DefaultTableModel) TableEquipo.getModel();
        
        setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Nombre = new javax.swing.JLabel();
        Titulo = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableEquipo = new javax.swing.JTable();
        BotonEliminar = new javax.swing.JButton();
        BotonRegistrar = new javax.swing.JButton();
        BotonEditar = new javax.swing.JButton();
        jTextFieldNombre = new javax.swing.JTextField();
        jTextField2Estadio = new javax.swing.JTextField();
        Estadio = new javax.swing.JLabel();
        BotonRegresar = new javax.swing.JButton();
        Imagen = new javax.swing.JLabel();
        Contenedor = new javax.swing.JLabel();
        wallpaper = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Nombre.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Nombre.setForeground(new java.awt.Color(255, 255, 255));
        Nombre.setText("Nombre");
        jPanel1.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, -1, 30));

        Titulo.setFont(new java.awt.Font("Waree", 1, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setText("Equipo");
        jPanel1.add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 0, 110, -1));

        TableEquipo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Estadio"
            }
        ));
        TableEquipo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableEquipoMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TableEquipo);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 540, 310));

        BotonEliminar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/basura.png"))); // NOI18N
        BotonEliminar.setText("Eliminar");
        BotonEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEliminarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 340, 170, -1));

        BotonRegistrar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonRegistrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/nota.png"))); // NOI18N
        BotonRegistrar.setText("Registrar");
        BotonRegistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonRegistrarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 220, 170, -1));

        BotonEditar.setFont(new java.awt.Font("Waree", 1, 14)); // NOI18N
        BotonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/editarcodigo.png"))); // NOI18N
        BotonEditar.setText("Editar");
        BotonEditar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BotonEditarMouseClicked(evt);
            }
        });
        jPanel1.add(BotonEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 280, 170, -1));

        jTextFieldNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldNombreKeyTyped(evt);
            }
        });
        jPanel1.add(jTextFieldNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 80, 120, -1));

        jTextField2Estadio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField2EstadioKeyTyped(evt);
            }
        });
        jPanel1.add(jTextField2Estadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 80, 110, -1));

        Estadio.setFont(new java.awt.Font("Waree", 1, 18)); // NOI18N
        Estadio.setForeground(new java.awt.Color(255, 255, 255));
        Estadio.setText("Estadio");
        jPanel1.add(Estadio, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, -1, 40));

        BotonRegresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/regresar.png"))); // NOI18N
        BotonRegresar.setContentAreaFilled(false);
        BotonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(BotonRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 420, -1, -1));

        Imagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/logo.png"))); // NOI18N
        jPanel1.add(Imagen, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 30, 150, 150));

        Contenedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/balon.jpg"))); // NOI18N
        jPanel1.add(Contenedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 0, 260, 540));

        wallpaper.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cancha.jpg"))); // NOI18N
        jPanel1.add(wallpaper, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 530));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 900, 530));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
   /**
     *el código verifica si los campos requeridos están completados y muestra un
     * mensaje de advertencia si no lo están. Si los campos están completados, 
     * crea una instancia de Equipo, establece los valores seleccionados en los
     * elementos nombre y estadio, y luego agrega el equipo a la lista y 
     * actualiza la tabla con los registros actualizados.
     * 
     */
    private void BotonRegistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonRegistrarMouseClicked

    if (jTextFieldNombre.getText().isEmpty() 
            || jTextField2Estadio.getText().isEmpty()) {
      
        JOptionPane.showMessageDialog(null, 
                "Tienes que rellenar los campos.");
        
    } else {
        
        Equipo equipo = new Equipo();
        equipo.setNombre(jTextFieldNombre.getText());
        equipo.setEstadio(jTextField2Estadio.getText());

        equipoController.crearRegistro(this.menuVista.listaEquipo, equipo);
      equipoController.mostrarRegistro(this.menuVista.listaEquipo, modelo);
    }
    
    }//GEN-LAST:event_BotonRegistrarMouseClicked

   /**
     *el código busca un equipo en la lista de equipos que tenga el mismo nombre
     * que el equipo seleccionado para editar. Si se encuentra un equipo con el 
     * mismo nombre, se actualiza en la lista y en el origen de datos correspondiente.
     * Luego, se actualiza el modelo de la tabla para mostrar los registros actualizados.
     * 
     */
    private void BotonEditarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEditarMouseClicked
  
         int filaSeleccionada = TableEquipo.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, 
                "Seleccione primero el elemento que desea editar.",
                "Error", JOptionPane.ERROR_MESSAGE);
        
        return;
    }

    Equipo equipo = new Equipo();
    equipo.setNombre(this.jTextFieldNombre.getText());
    equipo.setEstadio(this.jTextField2Estadio.getText());

    for (int i = 0; i < this.menuVista.listaEquipo.size(); i++) {
        
        if (this.menuVista.listaEquipo.get(i).getNombre()
                .compareTo(equipo.getNombre()) == 0) {
            
            this.menuVista.listaEquipo.set(i, equipo);
            
   equipoController.actualizarRegistro(this.menuVista.listaEquipo, equipo);
   
      equipoController.mostrarRegistro(this.menuVista.listaEquipo, modelo);
        }
    }

    }//GEN-LAST:event_BotonEditarMouseClicked
    
    /**
     *el código obtiene el nombre del equipo seleccionado en la tabla, muestra 
     * un cuadro de diálogo de confirmación y, si el usuario confirma la 
     * eliminación, elimina el equipo de la lista y actualiza el modelo de la 
     * tabla para mostrar los registros actualizados.
     * 
     */
    private void BotonEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BotonEliminarMouseClicked
      
         int filaSeleccionada = TableEquipo.getSelectedRow();

    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, 
                "Seleccione primero el elemento que desea eliminar.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
        String nombre = TableEquipo.getValueAt(TableEquipo.
                getSelectedRow(), 0).toString();
        
        int opcion = JOptionPane.showConfirmDialog(null, 
                "¿Estás seguro de eliminar?", "Confirmación", 
                JOptionPane.OK_CANCEL_OPTION);
        
        if (opcion == JOptionPane.OK_OPTION) {
       
     equipoController.eliminarRegistro(this.menuVista.listaEquipo, nombre);
     
      equipoController.mostrarRegistro(this.menuVista.listaEquipo, modelo);
        
        }

    }//GEN-LAST:event_BotonEliminarMouseClicked

    /**
     * cuando se hace clic en una celda de la tabla TableEquipo, este método 
     * recupera los valores de esa fila y los establece como elementos 
     * seleccionados en los componentes nombre y estadio. Esto permite que los 
     * valores de la fila seleccionada se muestren en los componentes 
     * correspondientes para su
     *
     */
    private void TableEquipoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableEquipoMouseClicked

        this.jTextFieldNombre.setText(TableEquipo.getValueAt(
                TableEquipo.getSelectedRow(), 0).toString());
        
        this.jTextField2Estadio.setText(TableEquipo.getValueAt(
                TableEquipo.getSelectedRow(), 1).toString());
        
    }//GEN-LAST:event_TableEquipoMouseClicked

    /**
     * al hacer clic en el botón "Regresar", la ventana actual se oculta y la 
     * ventana menuVista se muestra, lo que permite al usuario regresar al menú 
     * principal o a la ventana anterior.
     *  
     */
    private void BotonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegresarActionPerformed
       
        this.setVisible(false);
       
        this.menuVista.setVisible(true);

    }//GEN-LAST:event_BotonRegresarActionPerformed

    private void jTextFieldNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldNombreKeyTyped
        
        char letra = evt.getKeyChar();
        if (Character.isLetter(letra)) {
           
        } else {
            
            evt.consume();
            JOptionPane.showMessageDialog(null, 
                    "Solo se admiten letras");
        }
    }//GEN-LAST:event_jTextFieldNombreKeyTyped

    private void jTextField2EstadioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2EstadioKeyTyped
      
         char letra = evt.getKeyChar();
        if (Character.isLetter(letra)) {
           
        } else {
            
            evt.consume();
            JOptionPane.showMessageDialog(null, 
                    "Solo se admiten letras");
        }
    }//GEN-LAST:event_jTextField2EstadioKeyTyped
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonEditar;
    private javax.swing.JButton BotonEliminar;
    private javax.swing.JButton BotonRegistrar;
    private javax.swing.JButton BotonRegresar;
    private javax.swing.JLabel Contenedor;
    private javax.swing.JLabel Estadio;
    private javax.swing.JLabel Imagen;
    private javax.swing.JLabel Nombre;
    private javax.swing.JTable TableEquipo;
    private javax.swing.JLabel Titulo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField2Estadio;
    private javax.swing.JTextField jTextFieldNombre;
    private javax.swing.JLabel wallpaper;
    // End of variables declaration//GEN-END:variables
}
