/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Model equipo
 */
package model;

import entity.Equipo;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class EquipoModelImpl implements IEquipoModel {

    /**
     * El método crea un equipo
     * @param lista
     * @param equipo 
     */
    @Override
    public void crearRegistro(List<Equipo> lista, Equipo equipo) {
        lista.add(equipo);
    }

    /**
     * El método elimina un equipo
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Equipo> lista, String nombre) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(nombre) == 0) {
                lista.remove(i);

                break;
            }
        }
    }
    
    /**
     *El método actualiza un equipo
     * @param lista
     * @param equipo 
     */
    @Override
    public void actualizarRegistro(List<Equipo> lista, Equipo equipo) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(equipo.getNombre()) == 0) {
                lista.set(i, equipo);
                break;
            }
        }
    }

     /**
      * El método muestra un equipo
      * @param lista
      * @param modelo 
      */
    @Override
    public void mostrarRegistro(List<Equipo> lista, DefaultTableModel modelo) {
        modelo.setRowCount(0);
        for (int i = 0; i < lista.size(); i++) {
            Object[] fila = new Object[2];

            fila[0] = lista.get(i).getNombre();
            fila[1] = lista.get(i).getEstadio();

            modelo.addRow(fila);
        }
    }
}
