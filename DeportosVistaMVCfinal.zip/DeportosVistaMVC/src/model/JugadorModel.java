/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:Model del jugador
 */
package model;

import entity.Jugador;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class JugadorModel implements IJugadorModel {

    /**
     * El método crea un jugador
     * @param lista
     * @param jugador 
     */
    @Override
    public void crearRegistro(List<Jugador> lista, Jugador jugador) {
        lista.add(jugador);
    }

     /**
     * El método elimina un jugador
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Jugador> lista, String nombre) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(nombre) == 0) {
                lista.remove(i);

                break;
            }
        }
    }

    /**
     * /El método actualiza un jugador
     * @param lista
     * @param jugador 
     */
    @Override
    public void actualizarRegistro(List<Jugador> lista, Jugador jugador) {
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getNombre().compareTo(jugador.getNombre()) == 0) {
                lista.set(i, jugador);
                break;
            }
        }
    }

     /**
     *El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    @Override
    public void mostrarRegistro(List<Jugador> lista, DefaultTableModel modelo) {
        modelo.setRowCount(0);
        for (int i = 0; i < lista.size(); i++) {
            Object[] fila = new Object[4];

            fila[0] = lista.get(i).getNombre();
            fila[1] = lista.get(i).getPosicion();
            fila[2] = lista.get(i).getNumeroCamiseta();
            fila[3] = lista.get(i).getEquipo();

            modelo.addRow(fila);
        }
    }
}
