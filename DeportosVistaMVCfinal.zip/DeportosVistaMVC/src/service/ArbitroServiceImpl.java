/*
*Autor: America Yaridsaida Villalobos Rodriguez
*Fecha de creación:26/05/2023
*Fecha de actualización:27/05/2023
*Descripción:ventana vista Arbitro
 */
package service;

import entity.Arbitro;
import model.ArbitroModel;
import model.IArbitroModel;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ArbitroServiceImpl implements IArbitroService {

    IArbitroModel model = new ArbitroModel();

    /**
     * El método crea un árbitro
     * @param lista
     * @param arbitro 
     */
    @Override
    public void crearRegistro(List<Arbitro> lista, Arbitro arbitro) {
        model.crearRegistro(lista, arbitro);
    }

    /**
     * El método elimina un árbitro 
     * @param lista
     * @param nombre 
     */
    @Override
    public void eliminarRegistro(List<Arbitro> lista, String nombre) {
        model.eliminarRegistro(lista, nombre);
    }

    /**
     * El método actualiza un árbitro
     * @param lista
     * @param arbitro 
     */
    @Override
    public void actualizarRegistro(List<Arbitro> lista, Arbitro arbitro) {
        model.actualizarRegistro(lista, arbitro);
    }

    /**
     * El método muestra un árbitro
     * @param lista
     * @param modelo 
     */
    @Override
    public void mostrarRegistro(List<Arbitro> lista, DefaultTableModel modelo) {
        model.mostrarRegistro(lista, modelo);
    }

}
